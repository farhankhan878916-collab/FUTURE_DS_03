# Marketing Funnel & Conversion Performance Analysis

**Data Science & Analytics — Task 3 (2026)**
Internship task by [Future Interns](https://futureinterns.com/author/sujanshetty263gmail-com/)

## Problem Statement
Businesses lose money at every stage where a potential customer drops out of the
funnel (`Visitor → Lead → MQL → SQL → Customer`). This project analyzes a
marketing/lead funnel dataset to find **where users drop off, which channels
bring the highest-quality leads, and how conversion rates can be improved.**

## Dataset
A simulated, realistic marketing funnel dataset of **25,000 website visitors**
tracked through 5 stages, across 6 acquisition channels (Organic Search, Paid
Search, Paid Social, Email, Referral, Direct), 12 campaigns, 3 device types,
5 regions, and 6 months of activity (Oct 2025 – Mar 2026). Simulated data was
used per the task's dataset guidance ("simulated, anonymized, or business-specific
data" is allowed). See `data/generate_data.py` for the generation logic and the
assumptions behind each channel's conversion behavior.

| File | Description |
|---|---|
| `data/funnel_leads_data.csv` | Raw funnel dataset (25,000 rows) |
| `data/generate_data.py` | Script used to simulate the dataset |
| `notebooks/funnel_analysis.ipynb` | Full analysis notebook (cleaning, EDA, funnel & channel metrics, charts) |
| `visuals/` | Exported chart images (also shown below) |
| `INSIGHTS_AND_RECOMMENDATIONS.md` | Written summary of findings & recommendations |

## Tools Used
- **Python** (Jupyter Notebook) — pandas, numpy, matplotlib
- Analysis performed and documented following the funnel-analysis methodology
  outlined in the task brief.

## Funnel Overview

| Stage | Users Reaching Stage | % of Total Visitors | Conversion from Previous Stage |
|---|---:|---:|---:|
| Visitor | 25,000 | 100.00% | — |
| Lead | 4,126 | 16.50% | 16.50% |
| MQL | 2,303 | 9.21% | 55.82% |
| SQL | 1,214 | 4.86% | 52.71% |
| Customer | 517 | 2.07% | 42.59% |

**Overall Visitor → Customer conversion rate: 2.07%**

![Overall Funnel](visuals/01_overall_funnel.png)

## Where Are Users Dropping Off?

![Drop-off by Stage](visuals/02_dropoff_by_stage.png)

The single largest drop-off is at **Visitor → Lead (83.5% lost)** — this is a
top-of-funnel / landing page problem, not a sales problem. Every stage after
Lead retains 40–56% of users, which is healthy by comparison.

## Channel Performance

| Channel | Visitors | Leads | Customers | Visitor→Lead % | Lead→Customer % | Visitor→Customer % | Revenue |
|---|---:|---:|---:|---:|---:|---:|---:|
| Referral | 2,545 | 694 | 188 | 27.27% | 27.09% | **7.39%** | $1,000,255 |
| Email | 2,961 | 714 | 152 | 24.11% | 21.29% | **5.13%** | $695,207 |
| Paid Search | 5,032 | 720 | 64 | 14.31% | 8.89% | 1.27% | $242,507 |
| Organic Search | 6,935 | 807 | 83 | 11.64% | 10.29% | 1.20% | $357,351 |
| Direct | 2,000 | 260 | 15 | 13.00% | 5.77% | 0.75% | $63,102 |
| Paid Social | 5,527 | 931 | 15 | 16.84% | 1.61% | **0.27%** | $38,519 |

![Channel Conversion Comparison](visuals/03_channel_conversion_comparison.png)
![Revenue by Channel](visuals/04_revenue_by_channel.png)
![Monthly Trend](visuals/05_monthly_trend.png)

## Key Insights
1. **Referral and Email are the highest-quality channels** — smaller volume,
   but by far the best Lead→Customer conversion (27% and 21%) and the highest
   total revenue.
2. **Paid Social drives the most leads but converts the worst** (1.6%
   Lead→Customer) — high volume of low-intent traffic.
3. **83.5% of all visitors never become a lead** — this is the single biggest
   opportunity: even a small improvement in landing page / lead-capture
   conversion has an outsized impact on total customers.
4. **Conversion rates peak in November–December**, consistent with seasonal
   / holiday campaign intent.
5. Once someone becomes a Lead, roughly **1 in 8 leads eventually becomes a
   customer** (12.5% blended Lead→Customer rate).

## Recommendations
See [`INSIGHTS_AND_RECOMMENDATIONS.md`](INSIGHTS_AND_RECOMMENDATIONS.md) for
the full write-up, including specific, actionable recommendations for budget
reallocation, landing page optimization, lead scoring, and seasonal planning.

## How to Reproduce
```bash
pip install pandas numpy matplotlib
python data/generate_data.py          # regenerate the dataset
jupyter notebook notebooks/funnel_analysis.ipynb   # run the full analysis
```

---
*Task completed as part of the Future Interns Data Science & Analytics internship program.*
