# Key Drop-off Insights & Actionable Recommendations

## 1. Funnel Drop-off Summary

| From → To | Users Lost | Drop-off % |
|---|---:|---:|
| Visitor → Lead | 20,874 | 83.50% |
| Lead → MQL | 1,823 | 44.18% |
| MQL → SQL | 1,089 | 47.29% |
| SQL → Customer | 697 | 57.41% |

**Interpretation:** The funnel loses the vast majority of people before they
ever become a lead. Every stage after that is comparatively efficient —
meaning the business's core problem is **top-of-funnel conversion**, not deal
quality or sales execution.

## 2. Channel Quality vs. Volume

| Channel | Volume | Quality (Visitor→Customer) |
|---|---|---|
| Paid Social | Highest lead volume | **Lowest** quality (0.27%) |
| Organic Search | Highest visitor volume | Below-average quality (1.20%) |
| Referral | Lowest volume | **Highest** quality (7.39%) |
| Email | Low volume | 2nd highest quality (5.13%) |

This is a classic **volume vs. quality trade-off**. Channels optimized purely
for cheap clicks (Paid Social) fill the top of the funnel but rarely convert
to revenue. Relationship-driven channels (Referral, Email) convert far better
per visitor, even though they bring fewer people in.

## 3. Actionable Recommendations

### A. Fix the Visitor → Lead stage first (highest ROI fix)
- A/B test landing pages for the top 3 traffic sources (Organic Search, Paid
  Social, Paid Search) — these bring the most volume, so even a 2–3 point
  lift in lead capture rate translates into hundreds of extra leads.
- Shorten lead-capture forms, add social proof, and test faster page-load
  variants, especially on mobile (44% of traffic is mobile).

### B. Reallocate ~10–15% of Paid Social budget to Referral & Email
- Paid Social's Lead→Customer rate (1.6%) is roughly **17x worse** than
  Referral's (27.1%). Shifting a portion of that spend into a formal referral
  incentive program or an email nurture sequence should raise blended
  marketing ROI without materially reducing total lead volume.

### C. Tighten MQL → SQL qualification criteria
- Nearly half of MQLs never become SQLs (47% drop-off). Introducing or
  refining lead scoring (firmographic + behavioral signals) should route only
  sales-ready leads into SQL, improving SQL→Customer efficiency and freeing up
  sales rep time.

### D. Plan budget and staffing around the Nov–Dec seasonal peak
- Conversion rates rise measurably in November and December. Increasing ad
  spend and ensuring adequate sales follow-up capacity ahead of this window
  should capture more of the seasonal demand.

### E. Route leads by channel quality, not just recency
- Referral and Email leads should get priority/faster sales follow-up given
  their historically higher close rates — faster response time on
  high-quality leads is one of the cheapest levers to raise overall
  Lead→Customer conversion.

## 4. Summary Metric to Track Going Forward
**Blended Lead → Customer rate (currently ~12.5%)** is the single most useful
KPI to monitor month-over-month, since it reflects both lead quality (channel
mix) and sales-process efficiency (MQL→SQL→Customer) in one number.
