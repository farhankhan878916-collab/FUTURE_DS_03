"""
generate_data.py
-----------------
Generates a realistic, simulated marketing funnel dataset:
Visitor -> Lead -> MQL -> SQL -> Customer

Channels and campaigns have DIFFERENT conversion behavior on purpose,
so the analysis notebook has real, non-trivial insights to find.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

np.random.seed(42)

N_VISITORS = 25000
START_DATE = datetime(2025, 10, 1)
END_DATE = datetime(2026, 3, 31)
DAYS = (END_DATE - START_DATE).days

channels = ["Organic Search", "Paid Search", "Paid Social", "Email", "Referral", "Direct"]
channel_weights = [0.28, 0.20, 0.22, 0.12, 0.10, 0.08]

campaigns_by_channel = {
    "Organic Search": ["SEO-Blog", "SEO-Landing"],
    "Paid Search": ["Google-Brand", "Google-NonBrand"],
    "Paid Social": ["FB-Retarget", "IG-Awareness", "LinkedIn-B2B"],
    "Email": ["Newsletter", "Drip-Nurture"],
    "Referral": ["Partner-Program", "Affiliate"],
    "Direct": ["Direct-None"],
}

devices = ["Desktop", "Mobile", "Tablet"]
device_weights = [0.48, 0.44, 0.08]

regions = ["North", "South", "East", "West", "Central"]

# Stage conversion probabilities differ by channel (this creates the "story")
# Visitor -> Lead, Lead -> MQL, MQL -> SQL, SQL -> Customer
stage_conv = {
    "Organic Search": [0.10, 0.55, 0.50, 0.35],
    "Paid Search":    [0.14, 0.60, 0.45, 0.30],
    "Paid Social":    [0.16, 0.35, 0.30, 0.18],   # high traffic->lead but low quality downstream
    "Email":          [0.22, 0.65, 0.60, 0.45],   # smaller volume, high quality
    "Referral":       [0.25, 0.70, 0.65, 0.55],   # best quality leads
    "Direct":         [0.12, 0.50, 0.40, 0.30],
}

avg_deal_value = {
    "Organic Search": 4200, "Paid Search": 3800, "Paid Social": 2600,
    "Email": 4500, "Referral": 5200, "Direct": 3900,
}

rows = []
uid = 100000

for i in range(N_VISITORS):
    channel = np.random.choice(channels, p=channel_weights)
    campaign = np.random.choice(campaigns_by_channel[channel])
    device = np.random.choice(devices, p=device_weights)
    region = np.random.choice(regions)
    visit_day = START_DATE + timedelta(days=int(np.random.uniform(0, DAYS)))

    # add a mild seasonal boost around Nov-Dec (holiday campaigns) and March (fiscal year end)
    month = visit_day.month
    seasonal_boost = 1.15 if month in (11, 12) else (1.08 if month == 3 else 1.0)

    p_v2l, p_l2m, p_m2s, p_s2c = stage_conv[channel]
    p_v2l = min(p_v2l * seasonal_boost, 0.9)

    stage = "Visitor"
    lead_date = mql_date = sql_date = customer_date = pd.NaT
    revenue = 0

    if np.random.random() < p_v2l:
        stage = "Lead"
        lead_date = visit_day + timedelta(days=int(np.random.uniform(0, 2)))
        if np.random.random() < p_l2m:
            stage = "MQL"
            mql_date = lead_date + timedelta(days=int(np.random.uniform(1, 5)))
            if np.random.random() < p_m2s:
                stage = "SQL"
                sql_date = mql_date + timedelta(days=int(np.random.uniform(2, 10)))
                if np.random.random() < p_s2c:
                    stage = "Customer"
                    customer_date = sql_date + timedelta(days=int(np.random.uniform(3, 21)))
                    base_val = avg_deal_value[channel]
                    revenue = max(500, np.random.normal(base_val, base_val * 0.3))

    rows.append({
        "user_id": uid,
        "channel": channel,
        "campaign": campaign,
        "device": device,
        "region": region,
        "visit_date": visit_day.date(),
        "lead_date": lead_date.date() if pd.notna(lead_date) else None,
        "mql_date": mql_date.date() if pd.notna(mql_date) else None,
        "sql_date": sql_date.date() if pd.notna(sql_date) else None,
        "customer_date": customer_date.date() if pd.notna(customer_date) else None,
        "funnel_stage": stage,
        "revenue": round(float(revenue), 2),
    })
    uid += 1

df = pd.DataFrame(rows)
out_path = "/home/claude/marketing-funnel-analysis/data/funnel_leads_data.csv"
df.to_csv(out_path, index=False)
print(f"Saved {len(df):,} rows to {out_path}")
print(df["funnel_stage"].value_counts())
